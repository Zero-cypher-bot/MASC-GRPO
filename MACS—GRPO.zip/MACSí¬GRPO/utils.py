# utils.py
import os
import warnings
import numpy as np
import matplotlib.pyplot as plt

# 忽略作图时可能产生的警告
warnings.filterwarnings('ignore')

# ---------------------------------------------------------
# 全局图表配置
# ---------------------------------------------------------
plt.rcParams['font.sans-serif'] = ['SimHei']  # 解决中文显示方块问题
plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示为方块的问题

def create_directory(path: str, sub_dirs: list):
    for sub_dir in sub_dirs:
        full_path = os.path.join(path, sub_dir)
        if os.path.exists(full_path):
            print(full_path + ' is already exist!')
        else:
            os.makedirs(full_path, exist_ok=True)
            print(full_path + ' create successfully!')

def smooth(data, sm=1):
    """单条折线数据的平滑处理"""
    if sm > 1:
        z = np.ones(len(data))
        y = np.ones(sm) * 1.0
        return np.convolve(y, data, "same") / np.convolve(y, z, "same")
    return np.array(data)

def plot_learning_curve(episodes, records, title, ylabel, figure_file):
    plt.figure()
    plt.plot(episodes, records, linestyle='-', color='r')
    plt.title(title)
    plt.xlabel('episode')
    plt.ylabel(ylabel)
    plt.savefig(figure_file)
    plt.show()
    plt.close()

def smooth_plot(data, episode, title='Learning Curve', save_path=None):
    """进阶单线图：带平滑、网格、图例和高清保存"""
    y_data = smooth(data, sm=100)  # 固定 100 局平滑窗口
    x_data = np.arange(0, episode)

    plt.figure(figsize=(10, 6))
    plt.title(title, fontsize=14, fontweight='bold')
    plt.xlabel('episode', fontsize=12)
    plt.ylabel('objective value', fontsize=12)

    plt.plot(x_data, y_data, color='blue', linewidth=2, label='100-Ep Moving Average')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ 算法迭代图像已成功保存至: {save_path}")
    else:
        plt.show()
    plt.close()

def tsp(dist):
    """计算TSP的最短路径 (保留原逻辑以防外部调用)"""
    n = len(dist)
    if n <= 2:
        return 0
    dp = [[9999] * n for _ in range(1 << n)]
    dp[1][0] = 0

    for mask in range(1, 1 << n):
        for u in range(n):
            if mask & (1 << u):
                prev_mask = mask ^ (1 << u)
                for v in range(n):
                    if prev_mask & (1 << v):
                        dp[mask][u] = min(dp[mask][u], dp[prev_mask][v] + dist[v][u])

    min_cost = 9999
    for i in range(1, n):
        min_cost = min(min_cost, dp[(1 << n) - 1][i] + dist[i][0])

    return min_cost

# ---------------------------------------------------------
# 独立运行入口 (取代了原本的 ttt.py)
# ---------------------------------------------------------
if __name__ == '__main__':
    print("正在执行本地数据作图测试...")
    try:
        # 读取你想画图的本地 txt 文件
        data = np.loadtxt('DuelingDQN_rewards.txt', dtype=np.float32)
        smooth_plot(data, episode=len(data), title='Dueling DQN Training Curve')
    except FileNotFoundError:
        print("未找到 DuelingDQN_rewards.txt。请确认文件名是否正确，或者先运行 train_final.py 生成数据。")