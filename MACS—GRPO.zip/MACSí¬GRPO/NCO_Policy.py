# NCO_Policy.py
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class GATv2Layer(nn.Module):
    def __init__(self, in_dim, out_dim, heads=4):
        super().__init__()
        self.heads = heads
        self.out_dim = out_dim
        self.fc_src = nn.Linear(in_dim, heads * out_dim, bias=False)
        self.fc_dst = nn.Linear(in_dim, heads * out_dim, bias=False)
        self.attn = nn.Parameter(torch.Tensor(1, heads, out_dim))
        nn.init.xavier_uniform_(self.attn)

    def forward(self, x):
        B, N, _ = x.shape
        h_src = self.fc_src(x).view(B, N, self.heads, self.out_dim)
        h_dst = self.fc_dst(x).view(B, N, self.heads, self.out_dim)
        scores = F.leaky_relu(h_src.unsqueeze(2) + h_dst.unsqueeze(1))
        alpha = torch.einsum('bmnho,zho->bmnh', scores, self.attn)
        alpha = F.softmax(alpha, dim=2)
        out = torch.einsum('bmnh,bnho->bmho', alpha, h_dst)
        return out.reshape(B, N, self.heads * self.out_dim)


class SelectiveSSMBlock(nn.Module):
    """
    轻量化选择性状态空间模型 (Selective SSM / Mamba 核心算子)
    实现 O(N) 线性计算精度的上下文编码
    """
    def __init__(self, embed_dim, d_state=16):
        super().__init__()
        self.embed_dim = embed_dim
        self.d_state = d_state

        self.x_proj = nn.Linear(embed_dim, d_state * 2 + 1)
        self.dt_proj = nn.Linear(1, embed_dim)

        A = torch.repeat_interleave(torch.arange(1, d_state + 1, dtype=torch.float32), embed_dim)
        self.A_log = nn.Parameter(torch.log(A.view(embed_dim, d_state)))
        self.D = nn.Parameter(torch.ones(embed_dim))

        self.in_proj = nn.Linear(embed_dim, embed_dim * 2)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        residual = x
        x = self.norm(x)
        B, N, C = x.shape

        xz = self.in_proj(x)
        x_branch, z_branch = xz.chunk(2, dim=-1)

        ssm_param = self.x_proj(x_branch)
        B_param, C_param, dt = torch.split(ssm_param, [self.d_state, self.d_state, 1], dim=-1)
        dt = F.softplus(self.dt_proj(dt))

        A = -torch.exp(self.A_log)
        y = torch.zeros_like(x_branch)
        h = torch.zeros(B, C, self.d_state, device=x.device)

        for t in range(N):
            dt_t = dt[:, t, :].unsqueeze(-1)
            A_bar = torch.exp(A * dt_t)
            B_t = B_param[:, t, :].unsqueeze(1)
            x_t = x_branch[:, t, :].unsqueeze(-1)

            h = A_bar * h + (dt_t * B_t) * x_t

            C_t = C_param[:, t, :].unsqueeze(-1)
            y[:, t, :] = torch.matmul(h, C_t).squeeze(-1) + self.D * x_branch[:, t, :]

        out = y * F.silu(z_branch)
        return residual + self.out_proj(out)


class MACSIM_NCOPolicy(nn.Module):
    def __init__(self, state_dim, action_dim, embed_dim=128, lr=1e-4):
        super().__init__()
        self.action_dim = action_dim
        self.embed_dim = embed_dim

        self.state_proj = nn.Linear(state_dim, embed_dim)
        self.gat = GATv2Layer(embed_dim, embed_dim // 4, heads=4)
        self.ssm_encoder = SelectiveSSMBlock(embed_dim=embed_dim)

        self.actor_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.GELU(),
            nn.Linear(embed_dim, action_dim)
        )
        self.critic_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Linear(embed_dim // 2, 1)
        )

        self.optimizer = torch.optim.AdamW(self.parameters(), lr=lr, weight_decay=1e-4)
        self.to(device)

    def forward(self, state, valid_actions_mask=None):
        if state.dim() == 1:
            state = state.unsqueeze(0)

        x = F.gelu(self.state_proj(state)).unsqueeze(1)
        x = self.gat(x)
        x = self.ssm_encoder(x).squeeze(1)

        logits = self.actor_head(x)
        value = self.critic_head(x)

        if valid_actions_mask is not None:
            if valid_actions_mask.dim() == 1:
                valid_actions_mask = valid_actions_mask.unsqueeze(0)
            logits = torch.where(valid_actions_mask, logits, torch.tensor(-1e9, device=device))

        return logits, value


class MACSIMAgent:
    def __init__(self, state_dim, action_dim, lr=1e-4):
        self.action_dim = action_dim
        self.policy = MACSIM_NCOPolicy(state_dim, action_dim, lr=lr)

    def choose_action(self, state, valid_actions=None, isTrain=True, temperature=1.0):
        state_t = torch.tensor(np.array(state, dtype=np.float32), device=device)
        mask = torch.zeros(self.action_dim, dtype=torch.bool, device=device)
        if valid_actions is not None:
            mask[valid_actions] = True

        with torch.no_grad():
            logits, _ = self.policy(state_t, valid_actions_mask=mask)
            probs = F.softmax(logits / max(temperature, 1e-5), dim=-1)

        if isTrain:
            dist = torch.distributions.Categorical(probs)
            action = dist.sample().item()
        else:
            action = torch.argmax(probs, dim=-1).item()

        return action

    def train_batch_step(self, batch_trajectories):
        if len(batch_trajectories) == 0:
            return

        all_states, all_actions, all_masks, all_returns = [], [], [], []

        for states, actions, masks, returns in batch_trajectories:
            all_states.extend(states)
            all_actions.extend(actions)
            all_masks.extend(masks)
            all_returns.extend(returns)

        states_t = torch.tensor(np.array(all_states, dtype=np.float32), device=device)
        actions_t = torch.tensor(all_actions, dtype=torch.long, device=device)
        returns_t = torch.tensor(all_returns, dtype=torch.float32, device=device)
        masks_t = torch.stack([torch.tensor(m, device=device) for m in all_masks])

        if len(returns_t) > 1:
            returns_norm = (returns_t - returns_t.mean()) / (returns_t.std() + 1e-8)
        else:
            returns_norm = returns_t

        logits, values = self.policy(states_t, valid_actions_mask=masks_t)
        log_probs = F.log_softmax(logits, dim=-1)
        action_log_probs = log_probs.gather(1, actions_t.unsqueeze(1)).squeeze(1)

        advantages = returns_norm - values.squeeze(1)
        policy_loss = -(action_log_probs * advantages.detach()).mean()
        value_loss = F.mse_loss(values.squeeze(1), returns_norm)

        loss = policy_loss + 0.5 * value_loss

        self.policy.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 1.0)
        self.policy.optimizer.step()