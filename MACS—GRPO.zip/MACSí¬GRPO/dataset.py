import re
import ast
import os


def parse_opl_data(case_id):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, 'data', f'{case_id}.txt')

    # 如果没找到文件，打印出绝对路径，让你一眼看出该往哪放！
    if not os.path.exists(file_path):
        error_msg = f"""
            ====================================================
            ❌ 找不到数据文件！
            Python 正在你的电脑里死死盯着这个路径找：
            👉 {file_path}

            请你打开“我的电脑”，顺着上面这个路径找过去：
            1. 确认里面有没有 data 文件夹？
            # 修改后
            2. 确认 data 文件夹里有没有 {case_id}.txt？
            3. 【核心警告】检查文件后缀是不是变成了 {case_id}.txt.txt！
            ====================================================
            """
        raise FileNotFoundError(error_msg)
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. 剔除 OPL 的注释
    content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
    content = re.sub(r'//.*', '', content)

    # 2. 匹配所有的 变量名 = 值;
    matches = re.findall(r'(\w+)\s*=\s*([^;]+);', content)

    data_dict = {}
    for name, value_str in matches:
        value_str = value_str.strip()
        # 将 OPL 的集合 {} 替换为 Python 的列表 []
        value_str = value_str.replace('{', '[').replace('}', ']')

        try:
            # 将字符串安全地转化为 Python 数组/数字
            data_dict[name] = ast.literal_eval(value_str)
        except Exception as e:
            print(f"解析变量 {name} 时出错: {e}")

    # 3. 【核心步骤】CPLEX OPL 是从 1 开始索引的，而 Python 数组是从 0 开始的。
    # 我们需要把所有代表“序号”的数组全部减 1。
    def to_0_index(nested_list):
        res = []
        for item in nested_list:
            if isinstance(item, list):
                res.append(to_0_index(item))
            elif isinstance(item, int):
                res.append(item - 1)
        return res

    # 转换所有“基于 1 开始编号”的索引型集合/矩阵
    index_keys = ['Ii_P', 'Ii_C', 'Ko', 'Ip', 'Kl', 'KO', 'Kk']
    for key in index_keys:
        if key in data_dict:
            data_dict[key] = to_0_index(data_dict[key])

    return data_dict


# 测试一下是否能成功读取
if __name__ == '__main__':
    data = parse_opl_data('data1')  # 传入字符串名称进行测试
    print(f"成功读取！当前任务数 I = {data['I']}, 组件数 J = {data['J']}")
    print(f"前置任务 Ii_P[5] = {data['Ii_P'][5]}")
