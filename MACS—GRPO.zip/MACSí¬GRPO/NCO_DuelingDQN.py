# NCO_DuelingDQN.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random
from collections import deque

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class DuelingQNetwork(nn.Module):
    """Dueling Q-Network 架构"""

    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super().__init__()
        self.feature = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.GELU()
        )
        # V(s) 状态价值分支
        self.value_stream = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1)
        )
        # A(s, a) 动作优势分支
        self.advantage_stream = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, action_dim)
        )

    def forward(self, state, valid_actions_mask=None):
        if state.dim() == 1:
            state = state.unsqueeze(0)

        feat = self.feature(state)
        v = self.value_stream(feat)
        a = self.advantage_stream(feat)

        # 组合 Q(s, a) = V(s) + (A(s, a) - mean(A))
        q = v + (a - a.mean(dim=-1, keepdim=True))

        if valid_actions_mask is not None:
            if valid_actions_mask.dim() == 1:
                valid_actions_mask = valid_actions_mask.unsqueeze(0)
            q = q.masked_fill(~valid_actions_mask, -1e9)

        return q


class DuelingDQNAgent:
    """带有 Experience Replay 和 Action Masking 的 Dueling DQN Agent"""

    def __init__(self, state_dim, action_dim, lr=1e-3, gamma=0.99, buffer_capacity=10000):
        self.action_dim = action_dim
        self.gamma = gamma
        self.memory = deque(maxlen=buffer_capacity)

        self.q_net = DuelingQNetwork(state_dim, action_dim).to(device)
        self.target_net = DuelingQNetwork(state_dim, action_dim).to(device)
        self.target_net.load_state_dict(self.q_net.state_dict())

        self.optimizer = torch.optim.AdamW(self.q_net.parameters(), lr=lr)

    def choose_action(self, state, valid_actions=None, epsilon=0.1):
        if valid_actions is not None and random.random() < epsilon:
            return random.choice(valid_actions)

        state_t = torch.tensor(np.array(state, dtype=np.float32), device=device)
        mask = torch.zeros(self.action_dim, dtype=torch.bool, device=device)
        if valid_actions is not None:
            mask[valid_actions] = True

        with torch.no_grad():
            q_values = self.q_net(state_t, valid_actions_mask=mask)
            action = torch.argmax(q_values, dim=-1).item()

        return action

    def store_transition(self, state, action, reward, next_state, done, next_mask):
        self.memory.append((state, action, reward, next_state, done, next_mask))

    def train_step(self, batch_size=64):
        if len(self.memory) < batch_size:
            return 0.0

        batch = random.sample(self.memory, batch_size)
        states, actions, rewards, next_states, dones, next_masks = zip(*batch)

        states_t = torch.tensor(np.array(states), dtype=torch.float32, device=device)
        actions_t = torch.tensor(actions, dtype=torch.long, device=device).unsqueeze(1)
        rewards_t = torch.tensor(rewards, dtype=torch.float32, device=device).unsqueeze(1)
        next_states_t = torch.tensor(np.array(next_states), dtype=torch.float32, device=device)
        dones_t = torch.tensor(dones, dtype=torch.float32, device=device).unsqueeze(1)
        next_masks_t = torch.stack([torch.tensor(m, device=device) for m in next_masks])

        # 当前 Q 值估算
        q_eval = self.q_net(states_t).gather(1, actions_t)

        # Target Q 值计算
        with torch.no_grad():
            q_next = self.target_net(next_states_t, valid_actions_mask=next_masks_t)
            q_target = rewards_t + self.gamma * q_next.max(dim=1, keepdim=True)[0] * (1 - dones_t)

        loss = F.mse_loss(q_eval, q_target)

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.q_net.parameters(), 1.0)
        self.optimizer.step()

        return loss.item()

    def update_target_network(self):
        self.target_net.load_state_dict(self.q_net.state_dict())