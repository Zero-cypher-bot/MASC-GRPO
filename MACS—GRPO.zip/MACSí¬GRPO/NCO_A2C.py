# NCO_A2C.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class ActorCriticA2C(nn.Module):
    """A2C 系统的策略与价值网络"""

    def __init__(self, state_dim, action_dim, hidden_dim=128):
        super().__init__()
        self.actor = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, action_dim)
        )
        self.critic = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state, valid_actions_mask=None):
        if state.dim() == 1:
            state = state.unsqueeze(0)

        logits = self.actor(state)
        value = self.critic(state)

        if valid_actions_mask is not None:
            if valid_actions_mask.dim() == 1:
                valid_actions_mask = valid_actions_mask.unsqueeze(0)
            logits = logits.masked_fill(~valid_actions_mask, -1e9)

        return logits, value


class A2CAgent:
    """A2C (Advantage Actor-Critic) 智能体"""

    def __init__(self, state_dim, action_dim, lr=3e-4, gamma=0.99):
        self.action_dim = action_dim
        self.gamma = gamma

        self.policy = ActorCriticA2C(state_dim, action_dim).to(device)
        self.optimizer = torch.optim.AdamW(self.policy.parameters(), lr=lr)

    def choose_action(self, state, valid_actions=None, isTrain=True):
        state_t = torch.tensor(np.array(state, dtype=np.float32), device=device)
        mask = torch.zeros(self.action_dim, dtype=torch.bool, device=device)
        if valid_actions is not None:
            mask[valid_actions] = True

        with torch.no_grad():
            logits, value = self.policy(state_t, valid_actions_mask=mask)
            probs = F.softmax(logits, dim=-1)

        if isTrain:
            dist = torch.distributions.Categorical(probs)
            action = dist.sample().item()
        else:
            action = torch.argmax(probs, dim=-1).item()

        return action

    def train_step(self, states, actions, masks, total_return):
        """单条轨迹下的 Advantage 损失更新"""
        states_t = torch.tensor(np.array(states), dtype=torch.float32, device=device)
        actions_t = torch.tensor(actions, dtype=torch.long, device=device)
        masks_t = torch.stack([torch.tensor(m, device=device) for m in masks])
        return_t = torch.tensor([total_return], dtype=torch.float32, device=device)

        logits, values = self.policy(states_t, valid_actions_mask=masks_t)
        log_probs = F.log_softmax(logits, dim=-1)
        selected_log_probs = log_probs.gather(1, actions_t.unsqueeze(1)).squeeze(1)

        # Advantage = Return - V(s)
        advantages = return_t - values.squeeze(-1)

        actor_loss = -(selected_log_probs * advantages.detach()).mean()
        critic_loss = F.mse_loss(values.squeeze(-1), return_t.expand_as(values.squeeze(-1)))

        loss = actor_loss + 0.5 * critic_loss

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 1.0)
        self.optimizer.step()

        return loss.item()