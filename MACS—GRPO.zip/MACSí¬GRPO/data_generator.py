import numpy as np
import random


def generate_random_case(fixed_O=6, fixed_K=6):
    """
    根据提供的真实算例结构，精准生成的随机算例数据字典。
    操作员 O=6，操作台 K=6 严格锁死。
    """
    # 1. 随机生成任务数 I (15 到 260) 和 组件数 J (20 到 300)
    I = random.randint(15, 260)
    J = random.randint(20, 300)
    P = 3  # 真实数据里 P=3
    T = 2000  # 给一个充裕的时间上限
    L = 1

    # 2. 生成合法的有向无环图 (DAG) 作为前置关系
    Ii_P = [[] for _ in range(I)]
    Ii_C = [[] for _ in range(I)]  # 冲突矩阵暂留空，保持基础难度

    for j in range(1, I):
        # 30% 的概率有前置任务
        if random.random() < 0.3:
            num_pre = random.randint(1, min(3, j))
            # 只能从比 j 小的索引里挑，绝对保证无环
            pre_tasks = random.sample(range(j), num_pre)
            Ii_P[j] = pre_tasks

    # 3. 生成时间和成本矩阵 (贴合真实数据的取值范围)
    # 处理时间 t_d: K x I，真实数据在 2 到 18 之间
    t_d = np.random.randint(2, 20, size=(fixed_K, I)).tolist()
    # 成本 c: O x K x I，真实数据在 2.0 到 3.0 左右
    c = np.random.uniform(1.0, 4.0, size=(fixed_O, fixed_K, I)).tolist()

    # 4. 生成收益相关矩阵
    # 价值 v: J，真实数据在 150 到 200 左右
    v = np.random.uniform(100.0, 200.0, size=J).tolist()
    # Dj矩阵: J x I，包含 -1, 0, 1 (这里简化生成，确保算法能算出利润即可)
    Dj = np.random.randint(-1, 2, size=(J, I)).tolist()

    # 5. 生成容量和集合 (严格贴合真实数据的设定)
    ck_max = [2] * fixed_K  # 真实数据里都是 2
    ci_max = [2] * I  # 真实数据里都是 2

    # 假设所有操作员都能去所有工位（在随机训练中全连通可以增加泛化难度）
    Ko = [list(range(fixed_K)) for _ in range(fixed_O)]
    KO = [[] for _ in range(fixed_O)]
    Kl = [list(range(fixed_K))]

    # 产品划分简单处理
    Ip = [list(range(I))]

    return {
        "P": P, "I": I, "J": J, "O": fixed_O, "K": fixed_K, "T": T, "L": L,
        "Ip": Ip, "Ii_P": Ii_P, "Ii_C": Ii_C, "Kl": Kl, "Ko": Ko, "KO": KO,
        "v": v, "c": c, "t_d": t_d, "ck_max": ck_max, "ci_max": ci_max, "Dj": Dj
    }