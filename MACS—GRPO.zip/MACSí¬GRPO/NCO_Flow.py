# NCO_Flow.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class FlowNCOPolicy(nn.Module):
    """流匹配速度场预测网络：v_theta(x_t, t, s)"""

    def __init__(self, state_dim, action_dim, hidden_dim=128, lr=3e-4):
        super().__init__()
        self.action_dim = action_dim
        # 输入拼接: 调度状态 s (state_dim) + 流动位置 x_t (action_dim) + 连续时间步 t (1)
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim + 1, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, action_dim)
        )
        self.optimizer = torch.optim.AdamW(self.parameters(), lr=lr)
        self.to(device)

    def forward(self, state, x_t, t):
        if state.dim() == 1:
            state = state.unsqueeze(0)
        if x_t.dim() == 1:
            x_t = x_t.unsqueeze(0)
        if t.dim() == 1:
            t = t.unsqueeze(-1)
        inputs = torch.cat([state, x_t, t], dim=-1)
        return self.net(inputs)


class FlowNCOAgent:
    """Flow-NCO 智能体：通过连续速度场向量传输生成排产动作分布"""

    def __init__(self, state_dim, action_dim, lr=3e-4, ode_steps=5):
        self.action_dim = action_dim
        self.ode_steps = ode_steps
        self.policy = FlowNCOPolicy(state_dim, action_dim, lr=lr)

    def choose_action(self, state, valid_actions=None, isTrain=True, temperature=1.0):
        state_t = torch.tensor(np.array(state, dtype=np.float32), device=device).unsqueeze(0)
        mask = torch.zeros(self.action_dim, dtype=torch.bool, device=device)
        if valid_actions is not None:
            mask[valid_actions] = True

        # 1. 欧拉法求解神经常微分方程 (ODE Integration): 从噪声 x_0 积分推演至 x_1
        with torch.no_grad():
            x_t = torch.randn(1, self.action_dim, device=device)
            dt = 1.0 / self.ode_steps
            for step in range(self.ode_steps):
                t = torch.full((1, 1), step * dt, device=device)
                v = self.policy(state_t, x_t, t)
                x_t = x_t + v * dt

            # 2. 施加约束掩码并转换为动作概率
            logits = x_t.squeeze(0)
            logits = logits.masked_fill(~mask, -1e9)
            probs = F.softmax(logits / max(temperature, 1e-5), dim=-1)

        if isTrain:
            dist = torch.distributions.Categorical(probs)
            action = dist.sample().item()
        else:
            action = torch.argmax(probs, dim=-1).item()

        return action

    def train_flow_step(self, group_trajectories, group_rewards):
        """流匹配速度场损失更新：学习从标准先验噪声到最优轨迹动作的目标速度"""
        G = len(group_rewards)
        if G < 2:
            return 0.0

        best_idx = int(np.argmax(group_rewards))
        win_states, win_actions, _ = group_trajectories[best_idx]

        # 提取高收益排产方案作为目标解分布 x_1
        win_states_t = torch.tensor(np.array(win_states, dtype=np.float32), device=device)
        win_actions_t = torch.tensor(win_actions, dtype=torch.long, device=device)
        x_1 = F.one_hot(win_actions_t, self.action_dim).float()

        batch_size = x_1.shape[0]
        x_0 = torch.randn_like(x_1)
        t = torch.rand(batch_size, 1, device=device)

        # 连续插值轨迹与目标向量场
        x_t = (1.0 - t) * x_0 + t * x_1
        target_velocity = x_1 - x_0

        pred_velocity = self.policy(win_states_t, x_t, t)
        loss = F.mse_loss(pred_velocity, target_velocity)

        self.policy.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 1.0)
        self.policy.optimizer.step()

        return loss.item()