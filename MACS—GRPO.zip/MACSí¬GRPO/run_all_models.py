"""
================================================================================
Evaluation Pipeline: Greedy vs. Parallel POMO Inference Comparison
Description: Loads pre-trained weights for all 6 DRL models and evaluates both
             single-start greedy rollout and multi-start POMO search.
Ref: Section 5.3 (Table III: Computational Results) in the manuscript.
================================================================================
"""

import os
import time
import copy
import torch
import numpy as np
from env_final import DLBP_FinalEnv

# Import canonical baseline agents
from NCO_GRPO import MACSIMAgent
from NCO_Vanilla_GRPO import VanillaGRPOAgent
from NCO_RLOO import RLOOAgent
from NCO_DPO import DPOAgent
from NCO_KTO import KTOAgent
from NCO_PPO import PPOAgent

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def get_action_deterministic(agent, algo_type, obs, valid_actions):
    """Deterministic inference policy (Temperature = 0.0)."""
    if algo_type in ['MACS-GRPO', 'GRPO', 'RLOO', 'DPO', 'KTO']:
        return agent.choose_action(obs, valid_actions=valid_actions, isTrain=False, temperature=0.0)
    elif algo_type == 'PPO':
        res = agent.choose_action(obs, valid_actions=valid_actions, isTrain=False)
        return res[0] if isinstance(res, (tuple, list)) else res
    return valid_actions[0]


def evaluate_agent_both_modes(agent, algo_type, env):
    """
    Evaluate agent performance under both:
    1. Single-Start Greedy Rollout
    2. Multi-Start POMO Inference
    """
    with torch.no_grad():
        # 1. Single-Start Greedy Rollout
        obs = env.reset()
        done = False
        start_time_g = time.perf_counter()
        while not done:
            valid_actions = env.get_valid_actions()
            action = get_action_deterministic(agent, algo_type, obs, valid_actions)
            obs, _, done, _ = env.step(action)
        end_time_g = time.perf_counter()
        greedy_profit = env.total_profit
        greedy_schedule = copy.deepcopy(env.schedule)
        greedy_time = end_time_g - start_time_g

        # 2. Multi-Start POMO Search
        best_pomo_profit = -9999.0
        best_pomo_schedule = []
        env.reset()
        initial_valid_actions = env.get_valid_actions()

        start_time_p = time.perf_counter()
        for start_action in initial_valid_actions:
            if start_action == env.I:
                continue
            obs = env.reset()
            obs, _, done, _ = env.step(start_action)

            while not done:
                valid_actions = env.get_valid_actions()
                action = get_action_deterministic(agent, algo_type, obs, valid_actions)
                obs, _, done, _ = env.step(action)

            if env.total_profit > best_pomo_profit:
                best_pomo_profit = env.total_profit
                best_pomo_schedule = copy.deepcopy(env.schedule)

        end_time_p = time.perf_counter()
        pomo_time = end_time_p - start_time_p

        if best_pomo_profit == -9999.0:
            best_pomo_profit = greedy_profit

        return greedy_profit, greedy_schedule, greedy_time, best_pomo_profit, pomo_time


def print_schedule_details(algo_name, profit, schedule, inf_time):
    """Format and print micro-level disassembly dispatching schedule."""
    print("\n" + "=" * 80)
    print(f" [Evaluation Result] Algorithm: {algo_name:<18} | Net Profit: {profit:6.2f} | Time: {inf_time:.4f} s")
    print("=" * 80)
    if not schedule:
        print("  [Notice] No valid schedule extracted.")
        return

    print(f" {'Step':<6} | {'Resource':<12} | {'Station':<8} | {'Task':<8} | {'Time Window (s -> e)':<22}")
    print("-" * 80)
    for idx, step in enumerate(schedule[:12]):
        task, o, k, start_t, finish_t = step
        res_label = f"Robot {o+1}" if o < 4 else f"Human {o-3}"
        print(f" {idx + 1:02d}     | {res_label:<12} | W{k+1:<7} | T{task+1:02d}     | [{start_t:02d} -> {finish_t:02d}]")
    if len(schedule) > 12:
        print(f" ... and {len(schedule) - 12} additional disassembly tasks successfully committed.")


def main():
    case_id = 'case10'
    env = DLBP_FinalEnv(case_id=case_id)

    models_info = [
        ('MACS-GRPO', 'MACSIM-GRPO', MACSIMAgent, ['./checkpoints/grpo_best_model1.pth']),
        ('Vanilla GRPO', 'GRPO', VanillaGRPOAgent, ['./checkpoints/vanilla_grpo_best_model.pth']),
        ('RLOO', 'RLOO', RLOOAgent, ['./checkpoints/rloo_best_model.pth']),
        ('Trajectory-DPO', 'DPO', DPOAgent, ['./checkpoints/dpo_best_model.pth']),
        ('KTO', 'KTO', KTOAgent, ['./checkpoints/kto_best_model.pth']),
        ('PPO', 'PPO', PPOAgent, ['./checkpoints/ppo_best_model.pth'])
    ]

    summary_results = []
    print("\n" + "★" * 80)
    print(f" [Benchmark Evaluation] Instance: [{case_id}] | Comparing Greedy vs. POMO Search")
    print("★" * 80)

    for name, algo_type, agent_cls, candidate_paths in models_info:
        weight_path = None
        for p in candidate_paths:
            if os.path.exists(p):
                weight_path = p
                break

        if weight_path is None:
            print(f"\n[Warning] Checkpoint for [{name}] not found. Skipping evaluation.")
            continue

        agent = agent_cls(state_dim=env.state_dim, action_dim=env.action_dim)
        try:
            # Fixes vulnerability 2: map_location ensures CPU/GPU interoperability
            agent.policy.load_state_dict(torch.load(weight_path, map_location=device))
            agent.policy.eval()
            print(f"\n[Loaded] Checkpoint successfully loaded for [{name}]: {weight_path}")
        except Exception as e:
            print(f"\n[Error] Failed to load checkpoint for [{name}] ({weight_path}): {e}")
            continue

        g_profit, g_sched, g_time, p_profit, p_time = evaluate_agent_both_modes(agent, algo_type, env)
        summary_results.append((name, g_profit, p_profit, g_time, p_time))
        print_schedule_details(name, g_profit, g_sched, g_time)

    # Export academic comparative summary table
    print("\n" + "=" * 80)
    print(f" Table III: Computational Results for Case {case_id} (Greedy vs. POMO Search)")
    print("=" * 80)
    print(f" {'Algorithm':<18} | {'Greedy ($F$)':<14} | {'POMO ($F^*$)':<14} | {'Greedy Time (s)':<16} | {'POMO Time (s)':<14}")
    print("-" * 80)
    for name, gp, pp, gt, pt in summary_results:
        print(f" {name:<18} | {gp:<14.2f} | {pp:<14.2f} | {gt:<16.4f} | {pt:<14.4f}")
    print("=" * 80)


if __name__ == '__main__':
    main()