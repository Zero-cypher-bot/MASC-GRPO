# NCO_TDMPC2.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class TDMPC2Model(nn.Module):
    """TD-MPC2 核心复合网络：编码器、潜空间动力学转移、双 Q 网络及先验策略"""

    def __init__(self, state_dim, action_dim, latent_dim=64, lr=3e-4):
        super().__init__()
        self.action_dim = action_dim
        # 1. 状态编码器
        self.encoder = nn.Sequential(
            nn.Linear(state_dim, latent_dim),
            nn.ELU(),
            nn.Linear(latent_dim, latent_dim)
        )
        # 2. 潜空间动力学转移: z_{t+1} = T(z_t, a_t)
        self.dynamics = nn.Sequential(
            nn.Linear(latent_dim + action_dim, latent_dim),
            nn.ELU(),
            nn.Linear(latent_dim, latent_dim)
        )
        # 3. 奖励预测器: r = R(z_t, a_t)
        self.reward_fn = nn.Sequential(
            nn.Linear(latent_dim + action_dim, latent_dim),
            nn.ELU(),
            nn.Linear(latent_dim, 1)
        )
        # 4. 双 Q 价值评估网络
        self.q1 = nn.Sequential(
            nn.Linear(latent_dim + action_dim, latent_dim),
            nn.ELU(),
            nn.Linear(latent_dim, 1)
        )
        self.q2 = nn.Sequential(
            nn.Linear(latent_dim + action_dim, latent_dim),
            nn.ELU(),
            nn.Linear(latent_dim, 1)
        )
        # 5. 先验策略网络 (Actor)
        self.policy = nn.Sequential(
            nn.Linear(latent_dim, latent_dim),
            nn.ELU(),
            nn.Linear(latent_dim, action_dim)
        )
        self.optimizer = torch.optim.AdamW(self.parameters(), lr=lr)
        self.to(device)


class TDMPC2Agent:
    """TD-MPC2 智能体：结合潜空间 TD-learning 差分与测试期多步前瞻规划"""

    def __init__(self, state_dim, action_dim, latent_dim=64, lr=3e-4, horizon=3):
        self.action_dim = action_dim
        self.horizon = horizon
        self.model = TDMPC2Model(state_dim, action_dim, latent_dim, lr=lr)

    def choose_action(self, state, valid_actions=None, isTrain=True, temperature=1.0):
        state_t = torch.tensor(np.array(state, dtype=np.float32), device=device)
        mask = torch.zeros(self.action_dim, dtype=torch.bool, device=device)
        if valid_actions is not None:
            mask[valid_actions] = True

        with torch.no_grad():
            z = self.model.encoder(state_t.unsqueeze(0))
            logits = self.model.policy(z).squeeze(0)
            logits = logits.masked_fill(~mask, -1e9)
            probs = F.softmax(logits / max(temperature, 1e-5), dim=-1)

        # 训练阶段直接按先验策略采样
        if isTrain:
            dist = torch.distributions.Categorical(probs)
            return dist.sample().item()

        # 推理阶段：利用学到的动力学模型进行潜空间多步前瞻规划 (Latent MPC Planning)
        valid_indices = torch.where(mask)[0].cpu().numpy()
        if len(valid_indices) <= 1:
            return torch.argmax(probs, dim=-1).item()

        best_action = valid_indices[0]
        best_value = -1e9

        with torch.no_grad():
            for a_idx in valid_indices:
                a_vec = F.one_hot(torch.tensor(a_idx, device=device), self.action_dim).float().unsqueeze(0)
                cur_z = z
                cum_return = 0.0

                for h in range(self.horizon):
                    za = torch.cat([cur_z, a_vec], dim=-1)
                    r = self.model.reward_fn(za).item()
                    cum_return += (0.99 ** h) * r
                    cur_z = self.model.dynamics(za)
                    # 潜空间后续前瞻依先验策略展开
                    sub_logits = self.model.policy(cur_z)
                    a_next = torch.argmax(sub_logits, dim=-1)
                    a_vec = F.one_hot(a_next, self.action_dim).float()

                za_final = torch.cat([cur_z, a_vec], dim=-1)
                term_val = torch.min(self.model.q1(za_final), self.model.q2(za_final)).item()
                total_eval = cum_return + (0.99 ** self.horizon) * term_val

                if total_eval > best_value:
                    best_value = total_eval
                    best_action = a_idx

        return int(best_action)

    def train_tdmpc_step(self, group_trajectories, group_rewards):
        """联合优化：潜空间自监督预测 + 奖励一致性 + 时序差分双 Q 误差"""
        flat_states, flat_actions, flat_next_states, flat_rewards = [], [], [], []

        for states, actions, _ in group_trajectories:
            T = len(states)
            for t in range(T - 1):
                flat_states.append(states[t])
                flat_actions.append(actions[t])
                flat_next_states.append(states[t + 1])
                flat_rewards.append(0.0)
            if T > 0:
                flat_states.append(states[-1])
                flat_actions.append(actions[-1])
                flat_next_states.append(states[-1])
                flat_rewards.append(group_rewards[0] / T)

        if len(flat_states) == 0:
            return 0.0

        s_t = torch.tensor(np.array(flat_states, dtype=np.float32), device=device)
        a_t = F.one_hot(torch.tensor(flat_actions, dtype=torch.long, device=device), self.action_dim).float()
        s_next_t = torch.tensor(np.array(flat_next_states, dtype=np.float32), device=device)
        r_t = torch.tensor(flat_rewards, dtype=torch.float32, device=device).unsqueeze(-1)

        z = self.model.encoder(s_t)
        with torch.no_grad():
            z_next_target = self.model.encoder(s_next_t)

        za = torch.cat([z, a_t], dim=-1)
        z_next_pred = self.model.dynamics(za)
        r_pred = self.model.reward_fn(za)

        # 动力学与奖励模型损失
        dyn_loss = F.mse_loss(z_next_pred, z_next_target)
        rew_loss = F.mse_loss(r_pred, r_t)

        # 潜空间 Bellman 差分更新
        with torch.no_grad():
            next_logits = self.model.policy(z_next_target)
            a_next = F.one_hot(torch.argmax(next_logits, dim=-1), self.action_dim).float()
            za_next = torch.cat([z_next_target, a_next], dim=-1)
            q_target = r_t + 0.99 * torch.min(self.model.q1(za_next), self.model.q2(za_next))

        q1_loss = F.mse_loss(self.model.q1(za), q_target)
        q2_loss = F.mse_loss(self.model.q2(za), q_target)

        total_loss = q1_loss + q2_loss + rew_loss + 0.5 * dyn_loss

        self.model.optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        self.model.optimizer.step()

        return total_loss.item()